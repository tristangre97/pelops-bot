const html2img = require('./utility/HTML2IMG');

html = `
<b>Hello World</b>
`



console.log(html2img.makeTest(html, 'body'))