const buffs = {
      "In Water": {
        'boost': 80,
        'emoji': '💧',
        'units': ['Biollante Flower Beast', 'Biollante Plant Beast']
      },
      "Battra": {
        'boost': 30,
        'emoji': '<:Battra_Larva:982860056334831647>/<:Battra_Imago:982860055449858098>'
      },
      "Jet Jaguar 73": {
        'boost': 30,
        'emoji': '<:Jet_Jaguar_73:982860088714883162>'
      },
      "Spacegodzilla Crystals": {
        'boost': 25,
        'emoji': '<:SpacegodzillaCrystal:994763030518845500>'
      },
      "Below 33% HP": {
        'boost': 50,
        'emoji': '💔',
        'units': ['Godzilla Earth']
      },
    }
    const sayings = new Map();
