const cache = require('../utility/cache.js');
const db = require('../utility/database.js');
const crypto = require("crypto");

const {
    MessageEmbed,
    MessageActionRow,
    MessageButton
} = require('discord.js');
const randomDeck = require('../utility/randomDeck.js');




module.exports = {
    name: 'random_deck',
    category: 'Tools',
    description: 'Get a random deck',
    slash: "both",
    argsDescription: "The command category | the command name",
    testOnly: false,
    options: [{
        name: 'disable_unavailable_units', // Must be lower case
        description: 'Prevent unavailable units from appearing in the deck',
        required: false,
        type: 3,
        choices: [{
            name: 'True',
            value: 'True',
        }
        ]
    },],

    run: async ({
        message,
        interaction,
        channel,
        client,
        args,
        guild
    }) => {
        var [disable_unavailable_units] = args;
        if (!disable_unavailable_units) disable_unavailable_units = 'False';
        db.add(`stats.uses`)

        var interactionID = crypto.randomBytes(16).toString("hex");

        const waitEmbed = new MessageEmbed()
            .setColor('#ffb33c')
            .setTitle('Generating Deck...')
            .setDescription(`I am generating a random deck for you. This may take a second.`)
            .setImage('https://res.cloudinary.com/tristangregory/image/upload/v1660364006/gbl/pelops/random_deck.gif')

        reply = await interaction.reply({
            embeds: [waitEmbed],
        });

        randomDeckData = await randomDeck.get(interactionID, disable_unavailable_units)

        const embed = new MessageEmbed()
        embed.setColor('#ffb33c')
        embed.setDescription(`${cache.get(`randomDeckFinal_${interactionID}`).join(', ')}`)
        embed.setImage(`attachment://${interactionID}.png`)

        if (interaction.user.id === '222781123875307521') {
            embed.setFooter({ text: `Deck ID - ${interactionID}` })
        }

        actionBtns = new MessageActionRow();
        actionBtns.addComponents(
            new MessageButton()
            .setCustomId(`randomDeckBtn`)
            .setLabel(`Make Another Deck`)
            .setStyle('PRIMARY')
        )

        var reply = await interaction.editReply({
            content: `\`${randomDeckData.totalImgGenTime.toFixed(2)}ms\``,
            embeds: [],
            components: [actionBtns],
            files: [{
                attachment: randomDeckData.img,
                name: `${interactionID}.png`
            }]
        })
        // .then(async msg => {
        //     // msg.react('👍')
        //     // msg.react('👎')

        //     const SECONDS_TO_REPLY = 15 // replace 60 with how long to wait for message(in seconds).
        //     const MESSAGES_TO_COLLECT = 5
        //     const filter = (m) => m.author.id == interaction.user.id
        //     const collector = interaction.channel.createMessageCollector({ filter, time: SECONDS_TO_REPLY * 1000, max: MESSAGES_TO_COLLECT })
        //     collector.on('collect', async collected => {
        //         collected.content = collected.content.toLowerCase()
        //         if (collected.content.includes('deck sucks') || collected.content.includes('is bad') || collected.content.includes('is terrible') || collected.content.includes('are terrible') || collected.content.includes('terrible') || collected.content.includes('ass')) {
        //             await interaction.followUp({
        //                 content: `<@${interaction.user.id}> skill issue.`,
        //                 files: [{
        //                     attachment: 'https://res.cloudinary.com/tristangregory/image/upload/v1655007370/gbl/pelops/pelops_em.png',
        //                     name: 'yeet.png'
        //                 }]
        //             });

        //         }

        //     })


        // })


        function unavailiableCheck(unit) {
            if (!disable_unavailable_units) return false
            if (unavailiableUnits.includes(unit)) {
                return true
            } else {
                return false
            }
        }

    }
}



